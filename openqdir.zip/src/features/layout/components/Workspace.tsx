import { useEffect } from 'react'
import type { ReactNode } from 'react'

import { WorkspaceLayout, useWorkspaceStore } from '@/features/workspace'

interface WorkspaceProps {
  children?: ReactNode
}

let _wsRenders = 0

export function Workspace({ children }: WorkspaceProps) {
  console.debug('[Workspace] render #', ++_wsRenders, 'panesInitialized:', useWorkspaceStore.getState().panes.length > 0)

  const layout = useWorkspaceStore((s) => s.layout)
  const setLayout = useWorkspaceStore((s) => s.setLayout)
  const panesInitialized = useWorkspaceStore((s) => s.panes.length > 0)

  useEffect(() => {
    console.debug('[Workspace] effect: setLayout', layout, 'panesInitialized:', panesInitialized)
    if (!panesInitialized) {
      setLayout(layout)
    }
  }, [setLayout, panesInitialized, layout])

  return <WorkspaceLayout>{children}</WorkspaceLayout>
}
